class ModelNotFound(Exception):
    pass


class UserExists(Exception):
    pass
